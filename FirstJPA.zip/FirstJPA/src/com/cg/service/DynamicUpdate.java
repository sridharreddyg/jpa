package com.cg.service;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import com.cg.entity.Customer;

public class DynamicUpdate {
public static void main(String[] args) {
	EntityManagerFactory emf=Persistence.createEntityManagerFactory("FirstJPA");
	EntityManager entitymanager=emf.createEntityManager();
	entitymanager.getTransaction().begin();
	TypedQuery<Customer>query=entitymanager.createQuery("UPDATE Customer c set c.name='ram' where c.id=125",Customer.class);
	//query.setParameter("pname", "ram");
	query.executeUpdate();
	/*System.out.println(query);*/
	entitymanager.getTransaction().commit();
	entitymanager.close();
	emf.close();
}
}
