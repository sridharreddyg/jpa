package com.cg.service;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import com.cg.entity.Customer;

public class DynamicQueries1 {
	public static void main(String[] args) {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("FirstJPA");
		EntityManager entitymanager=emf.createEntityManager();
	
		entitymanager.close();
		emf.close();
	}
}
