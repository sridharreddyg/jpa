package com.cg.service;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import com.cg.entity.Customer;

public class DynamicQueries {
public static void main(String[] args) {
	EntityManagerFactory emf=Persistence.createEntityManagerFactory("FirstJPA");
	EntityManager entitymanager=emf.createEntityManager();
	TypedQuery<Customer>query=entitymanager.createQuery("SELECT customer FROM Customer customer WHERE customer.name=:pname",Customer.class);
	query.setParameter("pname", "ram");
	List<Customer> customer=query.getResultList();
	System.out.println(customer);
	entitymanager.close();
	emf.close();
}
}
