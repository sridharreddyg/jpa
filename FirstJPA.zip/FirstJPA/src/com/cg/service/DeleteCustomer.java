package com.cg.service;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.entity.Customer;

public class DeleteCustomer {
	public static void main(String[] args) {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("FirstJPA");
		EntityManager entitymanager=emf.createEntityManager();
		entitymanager.getTransaction().begin();
		Customer customer=entitymanager.find(Customer.class, 123);
	entitymanager.remove(customer);;
		/*customer.setAddress("sipcot");                                                            
		customer.setName("maneesh");*/
		/*entitymanager.persist(customer);*/
		entitymanager.getTransaction().commit();
		entitymanager.close();
		emf.close();
	}
}
