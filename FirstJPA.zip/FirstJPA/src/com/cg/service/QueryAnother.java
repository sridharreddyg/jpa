package com.cg.service;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import com.cg.entity.Customer;
import com.sun.xml.internal.ws.encoding.soap.SOAP12Constants;

public class QueryAnother {
public static void main(String[] args) {
	
	EntityManagerFactory emf=Persistence.createEntityManagerFactory("FirstJPA");
	EntityManager entitymanager=emf.createEntityManager();
/*	entitymanager.getTransaction().begin();*/
	String str="SELECT c FROM Customer c";
	TypedQuery<Customer>query=entitymanager.createQuery(str,Customer.class);
	
	List<Customer>list=query.getResultList();
	System.out.println(list);
/*	entitymanager.getTransaction().commit();*/
	entitymanager.close();
	emf.close();
}
}
