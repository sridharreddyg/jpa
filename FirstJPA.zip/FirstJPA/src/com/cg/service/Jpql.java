package com.cg.service;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.entity.Customer;

public class Jpql {
	public static void main(String[] args) {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("FirstJPA");
		EntityManager entitymanager=emf.createEntityManager();
		entitymanager.getTransaction().begin();
		Customer customer=entitymanager.find(Customer.class, 234);
		System.out.println("["+customer.getId()+" "+customer.getName()+" "+customer.getAddress()+"]");
		/*customer.setAddress("sipcot");                                                            
		customer.setName("maneesh");*/
		entitymanager.persist(customer);
		entitymanager.getTransaction().commit();
		entitymanager.close();
		emf.close();
	}
}
