package com.cg.service;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import com.cg.entity.Customer;

public class Query {
	public static void main(String[] args) {
	
	EntityManagerFactory emf=Persistence.createEntityManagerFactory("FirstJPA");
	EntityManager entitymanager=emf.createEntityManager();

	String str="SELECT customer FROM Customer customer WHERE customer.id='234'";
	TypedQuery<Customer>query=entitymanager.createQuery(str,Customer.class);
	Customer customer=query.getSingleResult();
	System.out.println(customer);

	entitymanager.close();
	emf.close();
}
}
