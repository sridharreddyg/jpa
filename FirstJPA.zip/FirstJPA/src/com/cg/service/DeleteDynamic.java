package com.cg.service;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import com.cg.entity.Customer;

public class DeleteDynamic {
public static void main(String[] args) {
	EntityManagerFactory emf=Persistence.createEntityManagerFactory("FirstJPA");
	EntityManager entitymanager=emf.createEntityManager();
	entitymanager.getTransaction().begin();
	TypedQuery<Customer>query=entitymanager.createQuery("Delete From Customer c where c.id=125",Customer.class);
	query.executeUpdate();
	entitymanager.getTransaction().commit();
	entitymanager.close();
	emf.close();
}
}
