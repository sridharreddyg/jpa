package com.cg.service;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.entity.Customer;

public class SaveCustomer {
public static void main(String[] args) {
	EntityManagerFactory emf=Persistence.createEntityManagerFactory("FirstJPA");
	EntityManager entitymanager=emf.createEntityManager();
	entitymanager.getTransaction().begin();
	Customer customer=new Customer();
	customer.setId(234);
	customer.setName("capgemini");
	customer.setAddress("mwc");
	customer.setId(123);
	customer.setName("sridhar");
	customer.setAddress("hyderabad");
	customer.setId(125);
	customer.setName("shifa");
	customer.setAddress("mp");
	customer.setId(126);
	customer.setName("sahith");
	customer.setAddress("hyderabad");
	entitymanager.persist(customer);
	entitymanager.getTransaction().commit();
	entitymanager.close();
	emf.close();
}
} 
