package com.cg.service;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.cg.entity.Customer;

public class JPQLDemo {
	public static void main(String[] args) {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("FirstJpa");
		EntityManager entityManager = emf.createEntityManager();
		Query query = entityManager.createQuery("SELECT s  from Customer s");
		List<Customer> list = query.getResultList();
		list.stream().forEach(System.out::println);
	}
}
