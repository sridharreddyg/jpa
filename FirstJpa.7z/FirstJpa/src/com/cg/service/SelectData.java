package com.cg.service;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.entity.Customer;

public class SelectData {
	public static void main(String[] args) {
		
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("FirstJpa");
		EntityManager entityManager = emf.createEntityManager();
		entityManager.getTransaction().begin();
		List<Customer> ListOfID = entityManager.createQuery("SELECT e FROM Customer e").getResultList();
		entityManager.getTransaction().commit();
		entityManager.close();
		emf.close();
	
	}
	} 
