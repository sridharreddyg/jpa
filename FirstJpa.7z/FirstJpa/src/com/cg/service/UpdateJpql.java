package com.cg.service;

public class UpdateJpql {

}
