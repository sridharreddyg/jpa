package com.cg.service;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.entity.Customer;

public class FetchCustomer {
	public static void main(String[] args) {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("FirstJpa");
		EntityManager entityManager = emf.createEntityManager();
		entityManager.getTransaction().begin();
		Customer customer = entityManager.find(Customer.class,13);
		System.out.println(customer.getId()+""+customer.getName()+" "+customer.getAddress());
		
		
		
		entityManager.getTransaction().commit();
		entityManager.close();
		emf.close();
	
	}
	}
		

