package com.cg.service;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.entity.Customer;

public class SaveCustomer {
	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("FirstJpa");
		EntityManager entityManager = emf.createEntityManager();
		entityManager.getTransaction().begin();
		Customer customer = new Customer();
		customer.setId(15);
		customer.setAddress("kerala");
		customer.setName("sushma2");

		entityManager.persist(customer);
		entityManager.getTransaction().commit();
		entityManager.close();
		emf.close();

	}

}
